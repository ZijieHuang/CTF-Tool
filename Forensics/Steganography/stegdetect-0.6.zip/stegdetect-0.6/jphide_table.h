#ifndef _JPHIDE_TABLE_
#define _JPHIDE_TABLE_
/* Public Domain */

#define TAIL1 12000
#define TAIL2 1200
#define TAIL3 120

extern int ltab[];
#endif /* _JPHIDE_TABLE_ */
